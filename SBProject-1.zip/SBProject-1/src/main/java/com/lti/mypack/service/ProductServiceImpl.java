package com.lti.mypack.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.mypack.model.Product;
import com.lti.mypack.repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements ProductService
{
	@Autowired
	ProductRepository prodRepo;

	@Override
	public List<Product> getProducts() {
		return prodRepo.findAll();
		
	}
	@Override
	public boolean addProduct(Product product) {
		
		prodRepo.save(product);
		return true;
	}
	@Override
	public boolean updateProduct(Product product) {
	
		prodRepo.save(product);
		return true;
	}
	@Override
	public boolean deleteProduct(int product) {
		prodRepo.deleteById(product);
		return true;
	}
	@Override
	public Product findProduct(int prodid) {
		return prodRepo.findById(prodid).get();
	}
	
	  @Override 
	  public List<Product> findProductByCategory(String category) 
	  {
		  	return prodRepo.findByCategory(category);
	  }
	@Override
	public List<Product> findProductByPriceRange(int lower, int upper) {
		
		return prodRepo.findByPriceRange(lower, upper);
	}
	 
	
	
	
	
}



